"""Converts SupplementaryData1_Children.tsv into a pedigree file."""
import pandas as pd

children = pd.read_csv("SupplementaryData1_Children.tsv", sep="\t")
ssc = children[children.collection == "SSC"]

# list of all individuals in SSC
persons = []
# each person is represented by a tuple:
# (familyId, personId, dadId, momId, status, sex)

for fam_id, members in ssc.groupby("familyId"):
    persons.append((fam_id, f"{fam_id}.mo", "0", "0", "unaffected", "F"))
    persons.append((fam_id, f"{fam_id}.fa", "0", "0", "unaffected", "F"))
    for child in members.to_dict(orient="records"):
        persons.append((
            fam_id, child["personId"], f"{fam_id}.fa", f"{fam_id}.mo",
            child["affected status"], child["sex"]))

with open("ssc_denovo.ped", "wt", encoding="utf8") as output:
    output.write(
        "\t".join(("familyId", "personId", "dadId", "momId", "status", "sex")))
    output.write("\n")

    for person in persons:
        output.write("\t".join(person))
        output.write("\n")
